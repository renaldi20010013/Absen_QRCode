package com.example.uasrungkad

import com.journeyapps.barcodescanner.CaptureActivity

class ScanViewActivity: CaptureActivity()
