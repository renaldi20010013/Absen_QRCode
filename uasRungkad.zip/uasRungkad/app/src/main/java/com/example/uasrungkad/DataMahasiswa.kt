package com.example.uasrungkad

data class DataMahasiswa(
    var nama: String,
    var nim: String,
    var email: String,
    var prodi: String
)
